<?php

namespace App\Http\Livewire\Admin\Services;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.admin.services.create');
    }
}
