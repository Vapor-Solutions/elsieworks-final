<?php

namespace App\Http\Livewire\Admin\Skills;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.admin.skills.index');
    }
}
