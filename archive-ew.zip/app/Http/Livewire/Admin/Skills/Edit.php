<?php

namespace App\Http\Livewire\Admin\Skills;

use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('livewire.admin.skills.edit');
    }
}
