<script src="/client/js/vendor/jquery.js"></script>
<script src="/client/js/vendor/modernizer.min.js"></script>
<script src="/client/js/vendor/feather.min.js"></script>
<script src="/client/js/vendor/slick.min.js"></script>
<script src="/client/js/vendor/bootstrap.js"></script>
<script src="/client/js/vendor/text-type.js"></script>
<script src="/client/js/vendor/wow.js"></script>
<script src="/client/js/vendor/aos.js"></script>
<script src="/client/js/vendor/particles.js"></script>
<!-- main JS -->
<script src="/client/js/main.js"></script>
