<x-app-layout>
    <x-slot name="header">
            {{ __('Dashboard') }}
    </x-slot>

    <div class="row">
        <div class="col-md-9">

        </div>
    </div>
</x-app-layout>
