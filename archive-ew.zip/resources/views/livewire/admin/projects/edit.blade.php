<div>
    <x-slot name="header">
        Edit Project No. {{ $id }}
    </x-slot>
</div>
