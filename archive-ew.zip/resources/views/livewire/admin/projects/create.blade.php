<div>
    <x-slot name="header">
        Create a new Project
    </x-slot>
</div>
