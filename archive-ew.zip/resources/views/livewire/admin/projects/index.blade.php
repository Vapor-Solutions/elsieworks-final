<div>
    <x-slot name="header">
        Projects' list
    </x-slot>
</div>
