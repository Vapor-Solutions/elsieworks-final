<div>
    <x-slot name="header">
        Edit Portfolio No.{{ $id }}
    </x-slot>
</div>
