<div>
    <x-slot name="header">
        Create a New Portfolio
    </x-slot>
</div>
