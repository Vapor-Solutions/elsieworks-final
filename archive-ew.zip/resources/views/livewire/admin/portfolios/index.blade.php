<div>
    <x-slot name="header">
        Portfolios' list
    </x-slot>
</div>
