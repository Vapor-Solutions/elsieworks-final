<div>
    {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
    <x-slot name="header">
        {{ __('Create a new Administrator') }}
    </x-slot>
</div>
