<div>
    {{-- Close your eyes. Count to one. That is how long forever feels. --}}
    <x-slot name="header">
        {{ __('Edit Blog No. ').$id }}
</x-slot>
</div>
