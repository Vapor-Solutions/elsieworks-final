<div>
    <x-slot name="header">
        {{ __('Create a new Blog Post') }}
    </x-slot>
</div>
