<div>
    {{-- Do your work, then step back. --}}
    <x-slot name="header">
        {{ __('Blog\' List') }}
    </x-slot>
</div>
