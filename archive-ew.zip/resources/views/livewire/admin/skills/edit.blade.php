<div>
    <x-slot name="header">
        Edit Your Modal
    </x-slot>
</div>
