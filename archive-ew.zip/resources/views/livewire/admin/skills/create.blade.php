<div>
    <x-slot name="header">
        Create a new Skill
    </x-slot>
</div>
