<div>
    <x-slot name="header">
        Skills' list
    </x-slot>
</div>
