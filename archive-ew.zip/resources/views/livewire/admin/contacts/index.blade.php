<div>
    <x-slot name="header">
        {{ __('Contacts\' List ') }}
    </x-slot>
</div>
